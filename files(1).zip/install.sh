#!/usr/bin/env bash
# ArchAI installer — run this ON your Arch Linux machine.
set -e

echo "==> [1/6] Installing system packages (python, tk, pip)"
sudo pacman -S --needed --noconfirm python python-pip tk

echo "==> [2/6] Installing Python dependency: sympy"
pip install --user --break-system-packages sympy 2>/dev/null || pip install --user sympy

echo "==> [3/6] Checking for Ollama"
if ! command -v ollama &> /dev/null; then
    if command -v yay &> /dev/null; then
        yay -S --needed --noconfirm ollama
    elif command -v paru &> /dev/null; then
        paru -S --needed --noconfirm ollama
    else
        echo "    No AUR helper found — using the official install script instead."
        curl -fsSL https://ollama.com/install.sh | sh
    fi
else
    echo "    Ollama already installed."
fi

echo "==> [4/6] Enabling the Ollama service"
sudo systemctl enable --now ollama

echo "==> [5/6] Pulling a default model (qwen2.5-coder:7b — good at code + reasoning)"
echo "    This is the only step that needs internet, and only happens once."
ollama pull qwen2.5-coder:7b

echo "==> [6/6] Installing ArchAI"
mkdir -p ~/.local/bin ~/.local/share/applications
cp arch_ai.py ~/.local/bin/archai
chmod +x ~/.local/bin/archai
cp archai.desktop ~/.local/share/applications/archai.desktop

if [[ ":$PATH:" != *":$HOME/.local/bin:"* ]]; then
    echo ""
    echo "NOTE: ~/.local/bin is not on your PATH."
    echo "Add this to your ~/.bashrc or ~/.zshrc:"
    echo '  export PATH="$HOME/.local/bin:$PATH"'
fi

echo ""
echo "Done. Launch with: archai"
echo "Or find 'ArchAI' in your application menu / rofi / dmenu."
