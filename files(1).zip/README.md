# ArchAI

An offline, Arch Linux–themed desktop assistant.

- **Chat & coding help** — powered by a local [Ollama](https://ollama.com) model.
  Fully offline once the model is pulled; no data leaves your machine.
- **Advanced math** — `/math` commands are answered *exactly* with SymPy
  (algebra, calculus, equations, matrices) — no LLM guessing involved.
- **Code** — the assistant writes and displays code in the chat. It does
  **not** execute anything automatically, by design.

## Install (on Arch Linux)

```bash
chmod +x install.sh
./install.sh
```

This will:
1. Install `python`, `tk`, `pip` via pacman.
2. `pip install sympy` for the math engine.
3. Install Ollama (via an AUR helper if you have `yay`/`paru`, otherwise the
   official installer script) and enable the systemd service.
4. Pull `qwen2.5-coder:7b` (~4-5 GB, one-time download — after this, ArchAI
   runs completely offline).
5. Install ArchAI to `~/.local/bin/archai` and add a menu entry.

Then launch it with:

```bash
archai
```

or find **ArchAI** in your app launcher / rofi / dmenu.

## Manual install / other distros

The app itself is pure standard library + SymPy (Tkinter GUI, no web
framework). It'll run on any Linux with Python 3 + Tk installed:

```bash
pip install sympy
python3 arch_ai.py
```

You still need `ollama` running locally (`ollama serve`, usually handled by
the systemd service) with at least one model pulled.

## Using a different / smaller model

Any coding-capable Ollama model works. Pull whichever fits your hardware,
then pick it from the dropdown in the top-right of the app:

```bash
ollama pull llama3.1:8b       # solid all-rounder
ollama pull qwen2.5-coder:7b  # strong at code (default)
ollama pull deepseek-coder-v2 # larger, stronger, needs more RAM/VRAM
ollama pull phi3:mini         # much lighter, weaker but fast on modest hardware
```

## Commands inside the app

```
/math <expression>        e.g. /math 2*x**2 + 3*x - 5 = 0
/math diff <expr>         derivative w.r.t. x
/math integrate <expr>    indefinite integral w.r.t. x
/math limit <expr> at x=<value>
/math solve <equation>
/math simplify|expand|factor <expr>
/math matrix <[[..],[..]]> det|inv|eig
/clear                    clear conversation history
/help                     show command help
```

Anything else is sent to the model as normal chat — ask it to write
functions, review code, explain an algorithm, or walk through math step by
step (for step-by-step explanation, plain chat; for an exact guaranteed
answer, use `/math`).

## Troubleshooting

- **"Could not reach Ollama"** — the service isn't running. Try:
  `sudo systemctl start ollama` (or `ollama serve` in a terminal).
- **Model dropdown only shows the fallback name** — Ollama has no models
  pulled yet, or the service isn't up when ArchAI starts. Pull a model and
  restart ArchAI.
- **Slow responses** — bigger models need more RAM/VRAM. Switch to a
  smaller model (e.g. `phi3:mini`) in the dropdown if it's dragging.
